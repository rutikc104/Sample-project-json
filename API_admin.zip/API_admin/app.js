const express = require('express')
const path = require('path')
const app = express();
var details = require('./data.json')
const bodyParser = require('body-parser')
const fs = require('fs')


app.get('/details/:role' , (req,res)=>{
    var result=details.details.filter(obj=> obj.role == req.params.role);
    res.json(result)
})


// mongoose.set('strictQuery', true);
// mongoose.connect("mongodb://localhost:27017/rest",()=>{
//     console.log("db connetced")})



const port = process.env.PORT || 3200
app.listen(port, ()=>
{
    console.log(`listening on port ${port}`)
})
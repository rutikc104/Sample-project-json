const express = require("express");

const Users =require("../models/userschema");

const bcrypt =require("bcryptjs")

const jwt =require("jsonwebtoken")

const route= express.Router()

route.get("/", (req,resp)=>{
         resp.send("Hii");
     })

     //REGISTER

route.post("/register", async (req,resp)=>{
    
//simple way to add data
    // Users.create(req.body);
    // resp.json("data added")

// 2 way
//    const { name, Lname ,email ,phone ,work ,password ,cpassword} =req.body;

//    if ( !name || !Lname || !email || !phone || !work || !password || !cpassword ){
//     return resp.status(422).json({error : "Plz filled the filed properly"});
//    } 

//    Users.findOne({email: email})
//    .then((userExist) =>{
//     console.log(userExist)
//     if (userExist) {
//         return resp.status(201).json({error : "Email already Exist"});
//     }
//     const user =new Users({name, Lname ,email ,phone ,work ,password ,cpassword});

//     user.save().then(() =>
//     {
//         resp.status(201).json({error :"successfuly"});
//     }).catch((err)=>resp.status(500,).json({error : "fail"})); 
//    }).catch(err =>{
//     console.log(err);
//    })

   const { name, Lname ,email ,phone ,role ,password ,cpassword} =req.body;

   if ( !name || !Lname || !email || !phone || !role || !password || !cpassword ){
    return resp.status(422).json({error : "Plz filled the filed properly"});
   } 

   try {

    const userExist =await Users.findOne({email: email});
    if (userExist) {
        return resp.status(201).json({error : "Email already Exist"});
    }

    const user =new Users({name, Lname ,email ,phone ,role ,password ,cpassword});
    await user.save();  
    resp.status(201).json({error :"successfuly"});

   } catch (err){
    console.log(err)
   }


});

//LOG IN

route.post("/log-in",async (req,resp)=>{

    try{
        const {email , password } =req.body
        if (!email || !password){
            return resp.status(400).json({error :"Plz Filled the data"})
        }

        const userLogin =await Users.findOne({email : email});

        //calling token function
        const token= await userLogin.generateAutoToken(); 

        resp.cookie("jwtoen",token,{
            expires: new Date(Date.now() +2592000000),
            httpOnly:this.true
        });
        console.log(token)
       
        
        if(userLogin){
            console.log(userLogin);
            console.log(userLogin.password)

            //we sued compared method to just compare our input password and database store encrypted password
            const match= await bcrypt.compare(password,userLogin.password);
            console.log(match);
            if (!match){
                resp.status(400).json({error :"Invalid"})}

            else{
                resp.json({message :"succeful"})    
            }
        }else{
            resp.status(400).json({error :"Invalid"})
        }


    }catch (err){
        console.log(err);
    }
})




 module.exports=route     
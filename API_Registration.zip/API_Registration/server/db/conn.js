const mongoose = require("mongoose");

mongoose.connection(process.env.DB,()=>{
    console.log("connection establish")
})

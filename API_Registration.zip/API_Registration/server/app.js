const express = require("express");
const mongoose = require("mongoose");
const dotenv=require("dotenv")

const app =express();

app.use(express.json());



dotenv.config({path: './server/config.env'})
 //Database connection

 require("./db/conn");
//we link the router file to make our routes easy

app.use(require("../routes/auth"));
//or
    //require("dotenv").config({path: './server/config.env'})

    //require("dotenv").config() 
    //our .env file should be in project main folder


//middlewaremk
    // const middleware =(req, resp, next)=>{
        
    //     next();
    // }

    // app.get("/", middleware, (req,resp)=>{
    //     resp.send("Hii");
    // })


//server
app.listen(5001 ,()=>{
    console.log("hello");
})
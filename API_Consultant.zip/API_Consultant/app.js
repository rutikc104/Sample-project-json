const express = require('express')

const app = express();
var clients = require('./data.json')


app.get('/clients',(req,res)=>{
    res.send(clients)
  })


const port = process.env.PORT || 3356
app.listen(port, ()=>
{
    console.log(`listening on port ${port}`)
})